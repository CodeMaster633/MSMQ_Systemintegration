﻿using Experimental.System.Messaging;
using Newtonsoft.Json;

namespace L08_Request_Reply
{
    class SAS
    {

        public SAS() { }

        public void SASRequest(MessageQueue requestQueue, MessageQueue replyQueue)
        {

            // Opret beskeden
            Message message = new Message();
            var messageBody = new
            {
                flightno = "SK345",
            };
            string jsonBody = JsonConvert.SerializeObject(messageBody);

            message.Body = jsonBody;
            message.Label = "Request af ETA";

            // Send beskeden til køen
            requestQueue.Send(message);

            Console.WriteLine("Besked sendt!");

            //Opsæt modtagelse q2
            replyQueue.Formatter = new XmlMessageFormatter(new String[] { "System.String" });
            replyQueue.ReceiveCompleted += new ReceiveCompletedEventHandler(OnMessage);
            replyQueue.BeginReceive();

        }
        public void OnMessage(object source, ReceiveCompletedEventArgs e)
        {
            try
            {
                Console.WriteLine("Hertil___");
                MessageQueue queue = (MessageQueue)source;
                Message message = queue.EndReceive(e.AsyncResult);

                queue.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });

                Console.WriteLine("Reply besked modtaget: " + (string)message.Body);

                queue.BeginReceive();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Fejl... " + ex.Message);
            }
        }
    }
}
